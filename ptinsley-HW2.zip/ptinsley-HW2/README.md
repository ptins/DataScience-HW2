# CSE40647/CSE60647 - HW2

This is the second assignment for my Data Science Class.

## Getting Started

This project uses Python 3.

Clone this repo with the following command.

```
git clone https://github.com/ptins/HW1-DataScience.git
```

## Enjoy!